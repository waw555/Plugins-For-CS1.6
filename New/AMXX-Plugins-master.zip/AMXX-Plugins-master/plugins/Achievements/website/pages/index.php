<?php
	Header( "Location: ../" );
?>